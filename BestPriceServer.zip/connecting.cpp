#include <QCoreApplication>
#include <QVariant>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>

int main(int argc, char *argv[]){
    QCoreApplication a(argc,argv);
    QSqlDatabase db =QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("Test");

    if(!db.open())
        qDebug()<<db.lastError().text();
    QSqlQuery query(db);
    query.exec("CREATE TABLE User(""login VARCHAR (20) not null,""password VARCHAR (20) NOT NULL"")");
    query.prepare("INSERT INTO User(login password)""VALUS(:login, :passowd)");
    query.bindValue(":password","123");
    query.bindValue(":login","admin");
    query.exec();
    query.prepare("INSERT INTO User(login,password)""VALUSE (:login,:password)");
    query.bindValue(":password","123");
    query.bindValue(":login","user");
    query.exec();
    query.exec("SELECT * FROM User");

    QSqlRecord rec= query.record();
    const int loginIndex = rec.indexOf("login");
    const int passwordIndex = rec.indexOf("password");
    while (query.next())
        qDebug()<<query.value(loginIndex).toString()<<"\t"<<query.value(passwordIndex)<<"\n";
    db.close();
    return a.exec();
}
