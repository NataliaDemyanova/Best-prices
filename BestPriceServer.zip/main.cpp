#include <QCoreApplication>
#include "mytcpserver.h"

int Qmain(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    MyTcpServer server;

    return a.exec();
}
