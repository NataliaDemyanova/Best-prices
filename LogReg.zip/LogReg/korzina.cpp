#include "korzina.h"
#include "ui_korzina.h"

korzina::korzina(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::korzina)
{
    ui->setupUi(this);
}

korzina::~korzina()
{
    delete ui;
}
