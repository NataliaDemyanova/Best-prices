/**
* \file
* \brief файл реализации методов класса reg.
*/
#include "user.h"
#include "ui_user.h"

user::user(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::user)
{
    ui->setupUi(this);
     this->setWindowTitle("Личный кабинет");
    this->setStyleSheet("background-color: 255, 255, 255;");
}
/**
 * @brief метод user::~user - деструктор класса reg
 *
 */
user::~user()
{
    delete ui;
}
/**
 * @brief метод on_pushButton_clicked закрывает окно при нажатии на кнопку "выход"
 * и открывает окно входа.
 */
void user::on_pushButton_clicked()
{
    this -> close();
    emit firstWindow();
}

