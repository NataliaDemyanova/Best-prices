/**
* \file
* \brief файл реализации методов класса reg.
*/
#include "reg.h"
#include "ui_reg.h"
#include <QMessageBox>

reg::reg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::reg)
{

    ui->setupUi(this);
    this->setWindowTitle("Регистрация");
    this->setStyleSheet("background-color: 255, 255, 255;");
}
/**
 * @brief метод reg::~reg - деструктор класса reg
 *
 */
reg::~reg()
{
    delete ui;
}

/**
 * @brief метод on_pushButton_clicked проверяет согласия пользователя.
 * Если пользователь согласен, то данное окно закрывается и вызывается окно входа.
 */

void reg::on_pushButton_clicked()
{
    if(ui ->checkBox ->isChecked() and ui ->checkBox_2 ->isChecked()) {
        this -> close();
        emit firstWindow();

    }else {
        QMessageBox::warning(this, "Ошибка входа", "Вы не согласны на обработку персональных данных или Вы не ознакомились с пользовательским соглашением!");
    }

}
