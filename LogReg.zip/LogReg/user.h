/**
* \file
* \brief заголовочный файл с описанием класса user.
*/
#ifndef USER_H
#define USER_H

#include <QDialog>

/**
 * @brief The Login class
 *
 * Данный класс имеет деструктор, сигнал для вызова другого окна для проверки авторизации и функции для клика по кнопке.
 *
 *
 */

namespace Ui {
class user;
}

class user : public QDialog
{
    Q_OBJECT

public:
    explicit user(QWidget *parent = nullptr);
    ~user();

signals:
    void firstWindow();

private slots:
    void on_pushButton_clicked();

private:
    Ui::user *ui;
};

#endif // USER_H
