#include "login.h"

#include <QApplication>

int Qmain(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Login w;
    w.show();
    return a.exec();
}
