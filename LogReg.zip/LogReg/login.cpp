/**
* \file
* \brief файл реализации методов класса Login.
*/
#include "login.h"
#include "./ui_login.h"
#include <QString>
#include <QMessageBox>
#include "user.h"
#include "reg.h"

Login::Login(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Login)
{
    ui->setupUi(this);
    this->setWindowTitle("Best Price");
       this->setStyleSheet("background-color: 255, 255, 255;");
    window = new user(this);
    connect(window, &user::firstWindow, this, &Login::show);
    reglist = new reg(this);
    connect(reglist, &reg::firstWindow, this, &Login::show);
}
/**
* @brief
* Login::~Login деструктор класса Login
*/
Login::~Login()
{
    delete ui;
}

/**
 * @brief метод check_auth
 * получает логин и пароль и сравнивает их с теми данными, с которомы возможен вход.
 */

bool Login::check_auth(QString login, QString password){

    if(login == "BestPrice" && password == "12345") {
        return 1;
    }else{
       return 0;
    }
}
/**
 * @brief метод on_vhod_clicked нужен для того, чтобы проверить данные для входа.
 * если данные неверные, то об этом оповещается.
 */
void Login::on_vhod_clicked()
{

    QString login = ui -> lineLogin -> text();
    QString password = ui -> linePass -> text();

    if(check_auth(login, password) == 1) {
        this -> close();
        window->show();
    }else {
        QMessageBox::warning(this, "Ошибка входа", "Неверный логин или пароль");

    }


}
/**
 * @brief метод on_vhod_clicked срабатывает при нажатии на кнопку "регистрация".
 * Закрывает окно входа и открывает окно регистрации.
 */
void Login::on_reg_clicked()
{
    this -> close();
    reglist -> open();
}


