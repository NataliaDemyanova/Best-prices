#ifndef KORZINA_H
#define KORZINA_H

#include <QDialog>

namespace Ui {
class korzina;
}

class korzina : public QDialog
{
    Q_OBJECT

public:
    explicit korzina(QWidget *parent = nullptr);
    ~korzina();

private:
    Ui::korzina *ui;
};

#endif // KORZINA_H
