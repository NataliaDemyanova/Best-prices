/**
* \file
* \brief заголовочный файл с описанием класса reg.
*/
#ifndef REG_H
#define REG_H

#include <QDialog>

/**
 * @brief The Login class
 *
 * Данный класс имеет деструктор, сигнал для вызова другого окна для проверки авторизации и функции для клика по кнопке.
 *
 *
 */

namespace Ui {
class reg;
}

class reg : public QDialog
{
    Q_OBJECT

public:
    explicit reg(QWidget *parent = nullptr);
    ~reg();

signals:
    void firstWindow();

private slots:

    void on_pushButton_clicked();

private:
    Ui::reg *ui;
};

#endif // REG_H
