<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>Login</name>
    <message>
        <location filename="login.ui" line="14"/>
        <source>BestPrice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="login.ui" line="54"/>
        <source>Логин:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="login.ui" line="97"/>
        <source>Пароль:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="login.ui" line="118"/>
        <source>Войти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="login.ui" line="131"/>
        <source>Регистрация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="login.ui" line="157"/>
        <source>Best Price</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>korzina</name>
    <message>
        <location filename="korzina.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="korzina.ui" line="26"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>reg</name>
    <message>
        <location filename="reg.ui" line="14"/>
        <source>Регистрация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="35"/>
        <source>                   Регистрация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="59"/>
        <source>Логин:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="89"/>
        <source>Пароль:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="110"/>
        <source>Согласен(а) на обработку персональных данных</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="123"/>
        <source>Ознакомлен(а) с пользовательским соглашением</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="reg.ui" line="141"/>
        <source>Зарегистрироваться!</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>register</name>
    <message>
        <location filename="register.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="31"/>
        <source>                     Регистрация</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="57"/>
        <source>Логин:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="89"/>
        <source>Пароль:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="110"/>
        <source>Согласен(а) на обработку персональных данных</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="123"/>
        <source>Ознакомлен(а) с пользовательским соглашением</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="register.ui" line="141"/>
        <source>Зарегистрироваться</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>user</name>
    <message>
        <location filename="user.ui" line="14"/>
        <source>Личный кабинет</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="35"/>
        <source>Выход</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="104"/>
        <source>Категория...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="109"/>
        <source>Продукты</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="114"/>
        <source>Электротовары</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="119"/>
        <source>Автозапчасти</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="133"/>
        <source>Город...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="138"/>
        <source>Москва</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="143"/>
        <source>Казань</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="148"/>
        <source>Екатеринбург</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="162"/>
        <source>Цена..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="167"/>
        <source>По возрастанию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="172"/>
        <source>По убыванию</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="user.ui" line="189"/>
        <source>Имя пользователя</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
