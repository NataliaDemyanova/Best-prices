#include "mytcpserver.h"
#include <QDebug>
#include <QCoreApplication>
#include <QString>
#include "functions.h"

MyTcpServer::~MyTcpServer()
{
    foreach(int i, SClients.keys())
    {
        QTextStream os(SClients[i]);
        SClients[i]->close();
        SClients.remove(i);
    }
    mTcpServer->close();
    server_status=0;
}
MyTcpServer::MyTcpServer(QObject *parent) : QObject(parent){
    mTcpServer = new QTcpServer(this);
    connect(mTcpServer, &QTcpServer::newConnection,
            this, &MyTcpServer::slotNewConnection);

    if(!mTcpServer->listen(QHostAddress::Any, 33333)){
        qDebug() << "server is not started";
    } else {
        server_status=1;
        qDebug() << "server is started";
    }
}

void MyTcpServer::slotNewConnection(){
    QTcpSocket* pClientSocket = m_ptcpServer->nextPendingConnection();
       connect(pClientSocket, SIGNAL(disconnected()),pClientSocket, SLOT(deleteLater()));
       connect(pClientSocket, SIGNAL(readyRead()),this,SLOT(slotReadClient()));

       sendToClient(pClientSocket, "Server Response: Connected!");
}

void MyTcpServer::slotServerRead(){
    QTcpSocket *clientSocket = (QTcpSocket*)sender();
    int id = (int)clientSocket->socketDescriptor();
    while(clientSocket->bytesAvailable()>0){
        QByteArray array =clientSocket->readAll();
        std::string log = "";
        std::string pass = "";
        std::string message;
        message = array.toStdString();
        qDebug()<<QString::fromStdString(message);
        int pos = message.find("&");
        message.erase(0,pos+1);
        pos = message.find("&");
        log = message.substr(0,pos);
        message.erase(0,pos+1);
        pos = message.find("&");
        pass = message.substr(0,pos);
        message.erase(0,pos+1);
        qDebug()<<"login ="<<QString::fromStdString(log)
               <<" password = "<< QString::fromStdString(pass)
              <<" result = " << authorize(log,pass);
        array.clear();
        array.append(authorize(log,pass));
        clientSocket->write(array);
    }
}
void MyTcpServer::slotReadClient()
{
    QTcpSocket* pClientSocket = (QTcpSocket*)sender();
    QDataStream in(pClientSocket);
    in.setVersion(QDataStream::Qt_4_2);
    for (;;) {
        if (!m_nNextBlockSize) {
            if (pClientSocket->bytesAvailable() < sizeof(quint16))
            {
                break;
            }
            in >> m_nNextBlockSize;
        }

        if (pClientSocket->bytesAvailable() < m_nNextBlockSize) {
            break;
        }
        QTime   time;
        QString str;
        in >> time >> str;

        QString strMessage =
            time.toString() + " " + "Client has sended - " + str;
        m_ptxt->append(strMessage);

        m_nNextBlockSize = 0;

        sendToClient(pClientSocket,"Server Response: Received \"" + str + "\"");
    }
}
void MyTcpServer::sendToClient(QTcpSocket* pSocket, const QString& str)
{
    QByteArray  arrBlock;
    QDataStream out(&arrBlock, QIODevice::WriteOnly);
    out.setVersion(QDataStream::Qt_4_2);
    out << quint16(0) << QTime::currentTime() << str;

    out.device()->seek(0);
    out << quint16(arrBlock.size() - sizeof(quint16));

    pSocket->write(arrBlock);
}
void MyTcpServer::slotClientDisconnected(){
    QTcpSocket *clientSocket = (QTcpSocket*)sender();
    int id = (int)clientSocket->socketDescriptor();
    clientSocket->close();
    SClients.remove(id);
    qDebug()<<QString::fromUtf8("Client is disconected \n");
}
