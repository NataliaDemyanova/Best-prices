#ifndef MYTCPSERVER_H
#define MYTCPSERVER_H
#include <QObject>
#include <QTcpServer>
#include <QTcpSocket>

#include <QtNetwork>
#include <QByteArray>
#include <QDebug>
#include <QSql>



class QTcpServer;
class QTextEdit;
class QTcpSocket;

class MyTcpServer : public QObject
{
    Q_OBJECT
private:
    QTcpServer* m_ptcpServer;
    QTextEdit*  m_ptxt;
    quint16     m_nNextBlockSize;
public:
    explicit MyTcpServer(QObject *parent = nullptr);
    ~MyTcpServer();
public slots:
 virtual void slotNewConnection();
    void slotClientDisconnected();
    void slotServerRead();
    void slotReadClient();
private:
    void sendToClient(QTcpSocket* pSocket, const QString& str);
private:
    QTcpServer * mTcpServer;
    int server_status;
    QMap<int,QTcpSocket*>SClients;

};
